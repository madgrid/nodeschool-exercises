//
//  ViewController.swift
//  E-Nail (beta)
//
//  Created by John Irwin on 4/2/16.
//  Copyright © 2016 Irwin Software. All rights reserved.
//
import CoreBluetooth
import UIKit

var myRemote = bluetoothBehaveRemote()
var myLocal = bluetootBehaveLocal()

class ViewController: UIViewController, bluetoothBehaveLocalDelegate{
    var currentValue = Int()
    @IBOutlet weak var devicesView: UIView!
    @IBOutlet weak var btConnectImage: UIImageView!
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var tempSlider: UISlider!
    var lastPosition: UInt16 = 100
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myLocal.addDesiredService("FFE0")
        myLocal.searchRepeats(2)
        myLocal.verboseOutput(true)

        }
    
   
    override func viewDidAppear(animated: Bool) {
        myLocal.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func debug(message: String) {
        
    }
    
    func receivedNotificationAsString(deviceID: NSUUID, string: String) {
        print("")
    }

    

    
    
    @IBAction func sliderValueChange(sender: UISlider) {
        
        currentValue = Int(sender.value)
        tempLabel.text = NSString(format: "\(currentValue)%@", "\u{00B0}") as String
        var message = "on " + String(currentValue)
        func updateTemp(sender: AnyObject) {
            // Make sure we are connected to something.
            if(myLocal.state() == DeviceState.states.connected){
                // Get the device ID.
                if let deviceID = myLocal.getConnectedDeviceIdByName("ALABTU"){
                    // Write a string to the device
                    myLocal.writeToDevice(deviceID, string: message)
                } else {
                    print("Device was not in connected device list.")
                }
            } else {
                print("Oh my! Your iOS device isn't connected to anything.")
            }
        }
        
    }
}

