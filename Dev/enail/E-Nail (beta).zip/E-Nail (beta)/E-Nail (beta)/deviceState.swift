

import Foundation

public class DeviceState {
    
    var hardwareState = hardwareStates.unknown
    var connectionState = connectionStates.unknown
    var searchState = searchStates.unknown
    public var state = states.unknown
    
    public enum states: Int {
        case unknown = 0,
        off,
        on,
        resetting,
        unsupported,
        unauthorized,
        connected,
        disconnected,
        failedToConnect,
        purposefulDisconnect,
        lostConnection,
        connecting,
        scanning,
        idle,
        idleWithDiscoveredDevices
    }

    
    public enum hardwareStates: Int {
        case unknown = 0,
        off,
        on,
        resetting,
        unsupported,
        unauthorized
    }
    
    public enum connectionStates: Int {
        case unknown = 0,
        connected,
        disconnected,
        failedToConnect,
        purposefulDisconnect,
        lostConnection,
        connecting
    }
    
    public enum searchStates: Int{
        case unknown = 0,
        scanning,
        idle,
        idleWithDiscoveredDevices
    }
}

